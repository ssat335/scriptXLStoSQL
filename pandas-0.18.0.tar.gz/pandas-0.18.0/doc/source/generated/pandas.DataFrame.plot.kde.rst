pandas.DataFrame.plot.kde
=========================

.. currentmodule:: pandas

.. autoaccessormethod:: DataFrame.plot.kde