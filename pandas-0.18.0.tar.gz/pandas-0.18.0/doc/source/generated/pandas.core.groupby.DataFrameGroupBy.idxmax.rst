pandas.core.groupby.DataFrameGroupBy.idxmax
===========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.idxmax