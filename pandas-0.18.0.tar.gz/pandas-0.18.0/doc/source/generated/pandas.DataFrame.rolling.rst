pandas.DataFrame.rolling
========================

.. currentmodule:: pandas

.. automethod:: DataFrame.rolling