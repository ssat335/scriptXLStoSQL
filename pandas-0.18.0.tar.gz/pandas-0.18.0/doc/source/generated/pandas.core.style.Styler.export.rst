pandas.core.style.Styler.export
===============================

.. currentmodule:: pandas.core.style

.. automethod:: Styler.export