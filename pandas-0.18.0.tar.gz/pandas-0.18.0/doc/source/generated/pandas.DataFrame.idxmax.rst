pandas.DataFrame.idxmax
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.idxmax