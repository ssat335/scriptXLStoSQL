pandas.core.style.Styler.highlight_max
======================================

.. currentmodule:: pandas.core.style

.. automethod:: Styler.highlight_max