pandas.CategoricalIndex.repeat
==============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.repeat