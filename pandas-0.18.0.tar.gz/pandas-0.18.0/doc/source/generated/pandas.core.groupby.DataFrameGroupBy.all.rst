pandas.core.groupby.DataFrameGroupBy.all
========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.all