pandas.DataFrame.plot.bar
=========================

.. currentmodule:: pandas

.. autoaccessormethod:: DataFrame.plot.bar