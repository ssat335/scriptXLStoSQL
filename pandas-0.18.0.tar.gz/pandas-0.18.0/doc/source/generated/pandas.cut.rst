pandas.cut
==========

.. currentmodule:: pandas

.. autofunction:: cut