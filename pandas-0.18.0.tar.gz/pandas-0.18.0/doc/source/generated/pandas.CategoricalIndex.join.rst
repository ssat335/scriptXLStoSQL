pandas.CategoricalIndex.join
============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.join