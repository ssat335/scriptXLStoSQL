pandas.DataFrame.filter
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.filter