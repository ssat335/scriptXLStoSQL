pandas.CategoricalIndex.order
=============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.order