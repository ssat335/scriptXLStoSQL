pandas.DataFrame.sample
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.sample