pandas.DataFrame.reorder_levels
===============================

.. currentmodule:: pandas

.. automethod:: DataFrame.reorder_levels