pandas.DataFrame.take
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.take