pandas.DataFrame.pivot_table
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.pivot_table