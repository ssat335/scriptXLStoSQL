pandas.DataFrame.round
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.round