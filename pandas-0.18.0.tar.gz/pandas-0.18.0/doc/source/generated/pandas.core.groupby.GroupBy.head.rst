pandas.core.groupby.GroupBy.head
================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.head