pandas.core.groupby.GroupBy.sum
===============================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.sum