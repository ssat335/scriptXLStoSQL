pandas.DataFrame.duplicated
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.duplicated