pandas.DataFrame.to_stata
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_stata