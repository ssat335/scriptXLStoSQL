pandas.DataFrame.to_records
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_records