pandas.DataFrame.skew
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.skew