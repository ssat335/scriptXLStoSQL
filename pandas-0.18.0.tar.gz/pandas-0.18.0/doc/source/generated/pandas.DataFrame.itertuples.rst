pandas.DataFrame.itertuples
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.itertuples