pandas.CategoricalIndex.holds_integer
=====================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.holds_integer