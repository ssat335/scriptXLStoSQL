pandas.CategoricalIndex.delete
==============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.delete