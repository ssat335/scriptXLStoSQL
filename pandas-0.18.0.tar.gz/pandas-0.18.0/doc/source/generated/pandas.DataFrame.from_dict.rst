pandas.DataFrame.from_dict
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.from_dict