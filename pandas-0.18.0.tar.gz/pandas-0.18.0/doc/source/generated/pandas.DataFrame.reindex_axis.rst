pandas.DataFrame.reindex_axis
=============================

.. currentmodule:: pandas

.. automethod:: DataFrame.reindex_axis