pandas.CategoricalIndex.reindex
===============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.reindex