pandas.core.groupby.DataFrameGroupBy.corr
=========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.corr