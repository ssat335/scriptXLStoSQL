pandas.CategoricalIndex.get_level_values
========================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.get_level_values