pandas.core.groupby.GroupBy.cumcount
====================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.cumcount