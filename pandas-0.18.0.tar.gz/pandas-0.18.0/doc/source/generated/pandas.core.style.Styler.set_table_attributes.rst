pandas.core.style.Styler.set_table_attributes
=============================================

.. currentmodule:: pandas.core.style

.. automethod:: Styler.set_table_attributes