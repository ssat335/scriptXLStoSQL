pandas.core.style.Styler.apply
==============================

.. currentmodule:: pandas.core.style

.. automethod:: Styler.apply