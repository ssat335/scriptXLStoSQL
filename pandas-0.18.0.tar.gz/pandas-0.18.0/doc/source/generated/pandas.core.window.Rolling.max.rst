pandas.core.window.Rolling.max
==============================

.. currentmodule:: pandas.core.window

.. automethod:: Rolling.max