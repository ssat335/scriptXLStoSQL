pandas.CategoricalIndex.names
=============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.names