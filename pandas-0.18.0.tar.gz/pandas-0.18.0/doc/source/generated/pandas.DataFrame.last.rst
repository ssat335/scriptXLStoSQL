pandas.DataFrame.last
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.last