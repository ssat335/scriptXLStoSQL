pandas.DataFrame.rmul
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.rmul