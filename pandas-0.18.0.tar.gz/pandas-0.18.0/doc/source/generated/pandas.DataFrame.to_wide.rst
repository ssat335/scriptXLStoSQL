pandas.DataFrame.to_wide
========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_wide