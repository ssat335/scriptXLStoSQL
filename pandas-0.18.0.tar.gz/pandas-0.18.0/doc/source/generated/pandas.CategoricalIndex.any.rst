pandas.CategoricalIndex.any
===========================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.any