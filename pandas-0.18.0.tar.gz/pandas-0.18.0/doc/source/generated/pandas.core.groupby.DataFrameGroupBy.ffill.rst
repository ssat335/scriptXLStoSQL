pandas.core.groupby.DataFrameGroupBy.ffill
==========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.ffill