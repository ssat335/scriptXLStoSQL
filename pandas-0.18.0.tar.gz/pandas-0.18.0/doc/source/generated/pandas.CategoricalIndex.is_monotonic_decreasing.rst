pandas.CategoricalIndex.is_monotonic_decreasing
===============================================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.is_monotonic_decreasing