pandas.core.style.Styler.set_table_styles
=========================================

.. currentmodule:: pandas.core.style

.. automethod:: Styler.set_table_styles