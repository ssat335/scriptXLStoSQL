pandas.CategoricalIndex.reorder_categories
==========================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.reorder_categories