pandas.DataFrame.corr
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.corr