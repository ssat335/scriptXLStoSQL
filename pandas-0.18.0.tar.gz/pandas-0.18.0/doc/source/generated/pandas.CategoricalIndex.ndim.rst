pandas.CategoricalIndex.ndim
============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.ndim