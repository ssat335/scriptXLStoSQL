pandas.CategoricalIndex.format
==============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.format