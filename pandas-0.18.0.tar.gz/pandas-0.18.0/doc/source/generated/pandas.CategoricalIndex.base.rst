pandas.CategoricalIndex.base
============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.base