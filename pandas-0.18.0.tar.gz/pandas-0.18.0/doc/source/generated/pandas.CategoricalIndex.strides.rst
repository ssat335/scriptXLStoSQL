pandas.CategoricalIndex.strides
===============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.strides