pandas.core.window.Expanding.apply
==================================

.. currentmodule:: pandas.core.window

.. automethod:: Expanding.apply