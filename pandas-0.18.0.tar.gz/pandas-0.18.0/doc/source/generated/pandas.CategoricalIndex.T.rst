pandas.CategoricalIndex.T
=========================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.T