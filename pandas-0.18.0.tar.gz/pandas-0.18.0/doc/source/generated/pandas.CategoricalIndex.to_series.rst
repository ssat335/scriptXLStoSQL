pandas.CategoricalIndex.to_series
=================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.to_series