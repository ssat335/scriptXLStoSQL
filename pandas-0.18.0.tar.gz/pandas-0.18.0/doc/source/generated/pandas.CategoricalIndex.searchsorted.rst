pandas.CategoricalIndex.searchsorted
====================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.searchsorted