pandas.CategoricalIndex.is_lexsorted_for_tuple
==============================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.is_lexsorted_for_tuple