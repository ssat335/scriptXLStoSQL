pandas.DataFrame.to_period
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_period