pandas.CategoricalIndex.sortlevel
=================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.sortlevel