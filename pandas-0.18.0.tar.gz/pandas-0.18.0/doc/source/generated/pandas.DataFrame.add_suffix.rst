pandas.DataFrame.add_suffix
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.add_suffix