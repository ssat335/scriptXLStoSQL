pandas.CategoricalIndex.get_values
==================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.get_values