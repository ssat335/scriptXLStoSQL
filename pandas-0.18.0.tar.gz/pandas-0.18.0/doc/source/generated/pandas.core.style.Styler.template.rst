pandas.core.style.Styler.template
=================================

.. currentmodule:: pandas.core.style

.. autoattribute:: Styler.template