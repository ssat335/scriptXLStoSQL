pandas.DataFrame.plot.box
=========================

.. currentmodule:: pandas

.. autoaccessormethod:: DataFrame.plot.box