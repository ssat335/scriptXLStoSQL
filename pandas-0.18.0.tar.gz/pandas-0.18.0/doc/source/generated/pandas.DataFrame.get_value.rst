pandas.DataFrame.get_value
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.get_value