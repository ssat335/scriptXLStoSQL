pandas.core.groupby.DataFrameGroupBy.cummin
===========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.cummin