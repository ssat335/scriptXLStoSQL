pandas.CategoricalIndex.dtype
=============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.dtype