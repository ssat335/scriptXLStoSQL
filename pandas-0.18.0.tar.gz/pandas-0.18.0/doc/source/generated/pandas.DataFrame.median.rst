pandas.DataFrame.median
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.median