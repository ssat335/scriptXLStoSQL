pandas.CategoricalIndex.drop_duplicates
=======================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.drop_duplicates