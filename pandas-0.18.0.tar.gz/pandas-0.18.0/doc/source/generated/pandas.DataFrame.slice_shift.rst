pandas.DataFrame.slice_shift
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.slice_shift