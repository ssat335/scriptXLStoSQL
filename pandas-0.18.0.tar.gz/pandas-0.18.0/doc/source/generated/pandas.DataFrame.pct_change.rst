pandas.DataFrame.pct_change
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.pct_change