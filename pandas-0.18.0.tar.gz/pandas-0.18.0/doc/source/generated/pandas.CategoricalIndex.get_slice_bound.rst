pandas.CategoricalIndex.get_slice_bound
=======================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.get_slice_bound