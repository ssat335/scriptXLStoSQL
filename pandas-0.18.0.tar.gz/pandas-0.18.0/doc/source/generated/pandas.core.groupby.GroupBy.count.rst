pandas.core.groupby.GroupBy.count
=================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.count