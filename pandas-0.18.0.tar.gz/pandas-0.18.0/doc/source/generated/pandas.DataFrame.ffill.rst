pandas.DataFrame.ffill
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.ffill