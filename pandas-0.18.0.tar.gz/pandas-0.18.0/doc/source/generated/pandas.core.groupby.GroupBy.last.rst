pandas.core.groupby.GroupBy.last
================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.last