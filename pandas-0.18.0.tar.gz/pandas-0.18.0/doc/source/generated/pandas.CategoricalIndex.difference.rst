pandas.CategoricalIndex.difference
==================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.difference