pandas.DataFrame.to_msgpack
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_msgpack