pandas.CategoricalIndex.asof
============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.asof