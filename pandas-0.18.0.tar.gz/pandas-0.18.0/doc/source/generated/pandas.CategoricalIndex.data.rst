pandas.CategoricalIndex.data
============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.data