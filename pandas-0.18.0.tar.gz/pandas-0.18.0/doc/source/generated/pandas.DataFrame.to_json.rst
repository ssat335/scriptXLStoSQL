pandas.DataFrame.to_json
========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_json