pandas.DataFrame.pipe
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.pipe