pandas.core.groupby.DataFrameGroupBy.quantile
=============================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.quantile