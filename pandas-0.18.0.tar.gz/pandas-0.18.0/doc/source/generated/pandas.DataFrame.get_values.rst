pandas.DataFrame.get_values
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.get_values