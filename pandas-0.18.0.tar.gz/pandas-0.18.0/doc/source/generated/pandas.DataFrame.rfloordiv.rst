pandas.DataFrame.rfloordiv
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.rfloordiv