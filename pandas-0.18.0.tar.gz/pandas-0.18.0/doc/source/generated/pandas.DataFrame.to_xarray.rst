pandas.DataFrame.to_xarray
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_xarray