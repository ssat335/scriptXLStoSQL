pandas.CategoricalIndex.map
===========================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.map