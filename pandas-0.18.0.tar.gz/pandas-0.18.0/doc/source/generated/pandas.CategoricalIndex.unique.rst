pandas.CategoricalIndex.unique
==============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.unique