pandas.CategoricalIndex.equals
==============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.equals