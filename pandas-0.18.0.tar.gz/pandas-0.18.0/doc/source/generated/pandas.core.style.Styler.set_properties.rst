pandas.core.style.Styler.set_properties
=======================================

.. currentmodule:: pandas.core.style

.. automethod:: Styler.set_properties