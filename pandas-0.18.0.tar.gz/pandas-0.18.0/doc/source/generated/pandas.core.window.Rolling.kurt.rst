pandas.core.window.Rolling.kurt
===============================

.. currentmodule:: pandas.core.window

.. automethod:: Rolling.kurt