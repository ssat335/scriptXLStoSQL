pandas.Categorical.__array__
============================

.. currentmodule:: pandas

.. automethod:: Categorical.__array__