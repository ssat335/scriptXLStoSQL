pandas.DataFrame.set_value
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.set_value