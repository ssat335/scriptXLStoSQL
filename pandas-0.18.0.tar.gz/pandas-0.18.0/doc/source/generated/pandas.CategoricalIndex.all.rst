pandas.CategoricalIndex.all
===========================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.all