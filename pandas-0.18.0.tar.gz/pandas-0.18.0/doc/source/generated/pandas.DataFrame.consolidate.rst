pandas.DataFrame.consolidate
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.consolidate