pandas.core.style.Styler.highlight_min
======================================

.. currentmodule:: pandas.core.style

.. automethod:: Styler.highlight_min