pandas.CategoricalIndex.ordered
===============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.ordered