pandas.CategoricalIndex.max
===========================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.max