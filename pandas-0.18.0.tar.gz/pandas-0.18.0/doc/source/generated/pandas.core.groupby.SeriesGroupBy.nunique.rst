pandas.core.groupby.SeriesGroupBy.nunique
=========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: SeriesGroupBy.nunique