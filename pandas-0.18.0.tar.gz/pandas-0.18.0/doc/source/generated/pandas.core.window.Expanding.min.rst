pandas.core.window.Expanding.min
================================

.. currentmodule:: pandas.core.window

.. automethod:: Expanding.min