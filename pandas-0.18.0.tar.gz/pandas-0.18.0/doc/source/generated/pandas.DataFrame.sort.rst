pandas.DataFrame.sort
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.sort