pandas.DataFrame.count
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.count