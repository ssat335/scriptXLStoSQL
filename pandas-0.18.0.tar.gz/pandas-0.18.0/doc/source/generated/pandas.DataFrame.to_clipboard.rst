pandas.DataFrame.to_clipboard
=============================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_clipboard