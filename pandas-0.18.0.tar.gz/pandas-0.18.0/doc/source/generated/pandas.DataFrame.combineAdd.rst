pandas.DataFrame.combineAdd
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.combineAdd