pandas.DataFrame.hist
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.hist