pandas.DataFrame.select
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.select