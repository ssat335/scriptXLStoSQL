pandas.core.groupby.DataFrameGroupBy.cov
========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.cov