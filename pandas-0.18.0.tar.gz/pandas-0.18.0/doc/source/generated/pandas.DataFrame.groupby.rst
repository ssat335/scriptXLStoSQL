pandas.DataFrame.groupby
========================

.. currentmodule:: pandas

.. automethod:: DataFrame.groupby