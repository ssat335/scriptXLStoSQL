pandas.CategoricalIndex.take
============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.take