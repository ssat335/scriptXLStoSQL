pandas.DataFrame.iterrows
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.iterrows