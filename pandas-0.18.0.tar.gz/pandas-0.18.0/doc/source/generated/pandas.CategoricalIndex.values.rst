pandas.CategoricalIndex.values
==============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.values