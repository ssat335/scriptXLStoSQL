pandas.CategoricalIndex.append
==============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.append