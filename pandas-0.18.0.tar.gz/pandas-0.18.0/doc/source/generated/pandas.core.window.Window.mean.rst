pandas.core.window.Window.mean
==============================

.. currentmodule:: pandas.core.window

.. automethod:: Window.mean