pandas.DataFrame.to_html
========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_html