pandas.DataFrame.kurt
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.kurt