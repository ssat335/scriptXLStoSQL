pandas.bdate_range
==================

.. currentmodule:: pandas

.. autofunction:: bdate_range