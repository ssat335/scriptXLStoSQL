pandas.DataFrame.convert_objects
================================

.. currentmodule:: pandas

.. automethod:: DataFrame.convert_objects