pandas.core.style.Styler.render
===============================

.. currentmodule:: pandas.core.style

.. automethod:: Styler.render