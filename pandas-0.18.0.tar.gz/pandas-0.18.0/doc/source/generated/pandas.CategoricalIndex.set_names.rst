pandas.CategoricalIndex.set_names
=================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.set_names