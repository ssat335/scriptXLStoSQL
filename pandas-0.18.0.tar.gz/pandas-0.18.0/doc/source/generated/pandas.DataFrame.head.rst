pandas.DataFrame.head
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.head