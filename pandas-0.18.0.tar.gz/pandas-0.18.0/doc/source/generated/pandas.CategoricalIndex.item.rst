pandas.CategoricalIndex.item
============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.item