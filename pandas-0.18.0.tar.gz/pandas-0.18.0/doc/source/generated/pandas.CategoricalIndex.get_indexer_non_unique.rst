pandas.CategoricalIndex.get_indexer_non_unique
==============================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.get_indexer_non_unique