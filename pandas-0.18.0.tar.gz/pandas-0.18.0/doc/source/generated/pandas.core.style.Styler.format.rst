pandas.core.style.Styler.format
===============================

.. currentmodule:: pandas.core.style

.. automethod:: Styler.format