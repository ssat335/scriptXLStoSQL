pandas.CategoricalIndex.str
===========================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.str