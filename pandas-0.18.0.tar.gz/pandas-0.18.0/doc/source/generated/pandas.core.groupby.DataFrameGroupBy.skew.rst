pandas.core.groupby.DataFrameGroupBy.skew
=========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.skew