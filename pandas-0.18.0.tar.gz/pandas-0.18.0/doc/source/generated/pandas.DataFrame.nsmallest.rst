pandas.DataFrame.nsmallest
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.nsmallest