pandas.CategoricalIndex.slice_locs
==================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.slice_locs