pandas.core.groupby.DataFrameGroupBy.pct_change
===============================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.pct_change