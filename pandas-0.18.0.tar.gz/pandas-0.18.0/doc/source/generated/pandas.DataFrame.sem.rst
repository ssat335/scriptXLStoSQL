pandas.DataFrame.sem
====================

.. currentmodule:: pandas

.. automethod:: DataFrame.sem