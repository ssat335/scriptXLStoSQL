pandas.DataFrame.squeeze
========================

.. currentmodule:: pandas

.. automethod:: DataFrame.squeeze