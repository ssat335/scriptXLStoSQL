pandas.CategoricalIndex.union
=============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.union