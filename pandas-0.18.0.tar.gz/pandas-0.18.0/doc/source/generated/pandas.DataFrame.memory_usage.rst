pandas.DataFrame.memory_usage
=============================

.. currentmodule:: pandas

.. automethod:: DataFrame.memory_usage