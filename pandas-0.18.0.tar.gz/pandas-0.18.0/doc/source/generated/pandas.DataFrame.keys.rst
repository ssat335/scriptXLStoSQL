pandas.DataFrame.keys
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.keys