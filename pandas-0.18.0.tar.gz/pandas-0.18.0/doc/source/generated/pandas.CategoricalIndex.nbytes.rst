pandas.CategoricalIndex.nbytes
==============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.nbytes