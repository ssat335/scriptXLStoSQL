pandas.CategoricalIndex.is_type_compatible
==========================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.is_type_compatible