pandas.DataFrame.style
======================

.. currentmodule:: pandas

.. autoattribute:: DataFrame.style