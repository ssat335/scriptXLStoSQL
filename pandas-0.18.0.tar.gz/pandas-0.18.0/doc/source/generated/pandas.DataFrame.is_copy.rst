pandas.DataFrame.is_copy
========================

.. currentmodule:: pandas

.. autoattribute:: DataFrame.is_copy