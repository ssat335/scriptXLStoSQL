pandas.core.style.Styler.clear
==============================

.. currentmodule:: pandas.core.style

.. automethod:: Styler.clear