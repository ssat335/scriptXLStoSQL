pandas.core.style.Styler.bar
============================

.. currentmodule:: pandas.core.style

.. automethod:: Styler.bar