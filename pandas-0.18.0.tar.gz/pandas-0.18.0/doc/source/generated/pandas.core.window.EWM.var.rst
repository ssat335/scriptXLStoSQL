pandas.core.window.EWM.var
==========================

.. currentmodule:: pandas.core.window

.. automethod:: EWM.var