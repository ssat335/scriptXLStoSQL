pandas.core.groupby.DataFrameGroupBy.rank
=========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.rank