pandas.DataFrame.sort_index
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.sort_index