pandas.DataFrame.dtypes
=======================

.. currentmodule:: pandas

.. autoattribute:: DataFrame.dtypes