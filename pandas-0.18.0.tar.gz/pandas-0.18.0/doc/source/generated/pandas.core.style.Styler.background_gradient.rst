pandas.core.style.Styler.background_gradient
============================================

.. currentmodule:: pandas.core.style

.. automethod:: Styler.background_gradient