pandas.DataFrame.nlargest
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.nlargest