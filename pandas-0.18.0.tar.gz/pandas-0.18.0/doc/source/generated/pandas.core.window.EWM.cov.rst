pandas.core.window.EWM.cov
==========================

.. currentmodule:: pandas.core.window

.. automethod:: EWM.cov