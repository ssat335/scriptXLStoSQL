pandas.DataFrame.combine
========================

.. currentmodule:: pandas

.. automethod:: DataFrame.combine