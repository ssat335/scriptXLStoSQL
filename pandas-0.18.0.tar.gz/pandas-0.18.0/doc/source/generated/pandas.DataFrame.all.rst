pandas.DataFrame.all
====================

.. currentmodule:: pandas

.. automethod:: DataFrame.all