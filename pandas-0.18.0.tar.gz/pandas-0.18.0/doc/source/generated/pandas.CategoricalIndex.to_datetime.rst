pandas.CategoricalIndex.to_datetime
===================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.to_datetime