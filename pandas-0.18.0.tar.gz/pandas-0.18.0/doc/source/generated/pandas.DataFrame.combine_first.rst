pandas.DataFrame.combine_first
==============================

.. currentmodule:: pandas

.. automethod:: DataFrame.combine_first