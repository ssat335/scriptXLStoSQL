pandas.CategoricalIndex.is_integer
==================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.is_integer