pandas.DataFrame.first
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.first