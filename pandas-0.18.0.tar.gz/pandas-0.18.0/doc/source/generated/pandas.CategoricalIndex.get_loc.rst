pandas.CategoricalIndex.get_loc
===============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.get_loc