pandas.CategoricalIndex.asi8
============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.asi8