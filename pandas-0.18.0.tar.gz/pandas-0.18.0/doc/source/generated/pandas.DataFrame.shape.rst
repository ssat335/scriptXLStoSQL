pandas.DataFrame.shape
======================

.. currentmodule:: pandas

.. autoattribute:: DataFrame.shape