pandas.CategoricalIndex.inferred_type
=====================================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.inferred_type