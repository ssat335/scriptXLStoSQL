pandas.CategoricalIndex.rename
==============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.rename