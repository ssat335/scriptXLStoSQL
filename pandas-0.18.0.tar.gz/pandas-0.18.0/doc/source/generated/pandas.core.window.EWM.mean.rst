pandas.core.window.EWM.mean
===========================

.. currentmodule:: pandas.core.window

.. automethod:: EWM.mean