pandas.DataFrame.equals
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.equals