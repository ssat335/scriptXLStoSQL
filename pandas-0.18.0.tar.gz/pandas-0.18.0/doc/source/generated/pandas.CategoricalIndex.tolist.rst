pandas.CategoricalIndex.tolist
==============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.tolist