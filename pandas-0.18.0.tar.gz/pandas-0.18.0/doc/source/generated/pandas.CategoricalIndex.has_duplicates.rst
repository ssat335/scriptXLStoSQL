pandas.CategoricalIndex.has_duplicates
======================================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.has_duplicates