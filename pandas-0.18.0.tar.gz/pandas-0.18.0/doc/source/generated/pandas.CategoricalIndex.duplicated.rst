pandas.CategoricalIndex.duplicated
==================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.duplicated