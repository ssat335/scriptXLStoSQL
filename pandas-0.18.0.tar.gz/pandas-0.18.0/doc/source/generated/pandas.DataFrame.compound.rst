pandas.DataFrame.compound
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.compound