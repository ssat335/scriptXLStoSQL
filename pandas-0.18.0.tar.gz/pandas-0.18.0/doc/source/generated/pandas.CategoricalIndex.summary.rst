pandas.CategoricalIndex.summary
===============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.summary