pandas.CategoricalIndex.is_mixed
================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.is_mixed