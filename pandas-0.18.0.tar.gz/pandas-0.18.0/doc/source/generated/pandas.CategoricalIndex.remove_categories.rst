pandas.CategoricalIndex.remove_categories
=========================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.remove_categories