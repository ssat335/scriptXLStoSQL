pandas.core.groupby.SeriesGroupBy.nlargest
==========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: SeriesGroupBy.nlargest