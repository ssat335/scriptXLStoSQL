pandas.DataFrame.mask
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.mask