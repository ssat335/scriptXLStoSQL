pandas.core.style.Styler
========================

.. currentmodule:: pandas.core.style

.. autoclass:: Styler

   


..
   HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
   .. autosummary::
      :toctree:
      
      Styler.apply
      Styler.applymap
      Styler.background_gradient
      Styler.bar
      Styler.clear
      Styler.export
      Styler.format
      Styler.highlight_max
      Styler.highlight_min
      Styler.highlight_null
      Styler.render
      Styler.set_caption
      Styler.set_precision
      Styler.set_properties
      Styler.set_table_attributes
      Styler.set_table_styles
      Styler.set_uuid
      Styler.use




   


..
   HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
   .. autosummary::
      :toctree:
      
      Styler.template


