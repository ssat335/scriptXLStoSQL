pandas.core.window.Rolling.count
================================

.. currentmodule:: pandas.core.window

.. automethod:: Rolling.count