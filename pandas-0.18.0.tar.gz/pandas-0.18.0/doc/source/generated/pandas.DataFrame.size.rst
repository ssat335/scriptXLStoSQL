pandas.DataFrame.size
=====================

.. currentmodule:: pandas

.. autoattribute:: DataFrame.size