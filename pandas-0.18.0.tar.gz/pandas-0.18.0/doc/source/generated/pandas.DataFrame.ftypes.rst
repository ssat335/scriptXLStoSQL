pandas.DataFrame.ftypes
=======================

.. currentmodule:: pandas

.. autoattribute:: DataFrame.ftypes