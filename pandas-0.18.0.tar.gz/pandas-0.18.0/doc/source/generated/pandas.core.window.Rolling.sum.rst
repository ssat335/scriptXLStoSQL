pandas.core.window.Rolling.sum
==============================

.. currentmodule:: pandas.core.window

.. automethod:: Rolling.sum