pandas.CategoricalIndex.hasnans
===============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.hasnans