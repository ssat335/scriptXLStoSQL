pandas.CategoricalIndex.nlevels
===============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.nlevels