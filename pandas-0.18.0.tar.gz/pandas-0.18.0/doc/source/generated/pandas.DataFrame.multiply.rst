pandas.DataFrame.multiply
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.multiply