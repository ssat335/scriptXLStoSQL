pandas.core.groupby.DataFrameGroupBy.cumprod
============================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.cumprod