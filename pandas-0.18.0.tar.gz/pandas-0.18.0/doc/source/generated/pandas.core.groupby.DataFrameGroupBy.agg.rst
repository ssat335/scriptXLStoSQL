pandas.core.groupby.DataFrameGroupBy.agg
========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.agg