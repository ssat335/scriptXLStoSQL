pandas.CategoricalIndex.as_unordered
====================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.as_unordered