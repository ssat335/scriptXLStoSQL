pandas.DataFrame.plot.line
==========================

.. currentmodule:: pandas

.. autoaccessormethod:: DataFrame.plot.line