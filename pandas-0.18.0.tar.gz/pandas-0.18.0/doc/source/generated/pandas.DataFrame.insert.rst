pandas.DataFrame.insert
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.insert