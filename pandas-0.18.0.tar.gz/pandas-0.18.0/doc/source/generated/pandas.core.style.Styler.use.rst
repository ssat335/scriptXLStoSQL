pandas.core.style.Styler.use
============================

.. currentmodule:: pandas.core.style

.. automethod:: Styler.use