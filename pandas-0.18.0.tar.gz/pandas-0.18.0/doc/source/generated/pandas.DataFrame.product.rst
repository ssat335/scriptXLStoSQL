pandas.DataFrame.product
========================

.. currentmodule:: pandas

.. automethod:: DataFrame.product