pandas.DataFrame.to_timestamp
=============================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_timestamp