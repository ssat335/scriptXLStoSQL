pandas.core.window.Expanding.kurt
=================================

.. currentmodule:: pandas.core.window

.. automethod:: Expanding.kurt