pandas.core.style.Styler.set_precision
======================================

.. currentmodule:: pandas.core.style

.. automethod:: Styler.set_precision