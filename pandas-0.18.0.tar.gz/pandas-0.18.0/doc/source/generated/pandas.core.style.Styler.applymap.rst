pandas.core.style.Styler.applymap
=================================

.. currentmodule:: pandas.core.style

.. automethod:: Styler.applymap