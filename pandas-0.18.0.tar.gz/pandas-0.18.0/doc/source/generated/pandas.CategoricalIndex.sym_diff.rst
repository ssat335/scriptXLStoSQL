pandas.CategoricalIndex.sym_diff
================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.sym_diff