pandas.CategoricalIndex.is_unique
=================================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.is_unique