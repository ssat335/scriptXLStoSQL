pandas.core.window.Expanding.mean
=================================

.. currentmodule:: pandas.core.window

.. automethod:: Expanding.mean