pandas.core.groupby.DataFrameGroupBy.diff
=========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.diff