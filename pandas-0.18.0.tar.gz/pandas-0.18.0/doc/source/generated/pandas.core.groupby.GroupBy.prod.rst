pandas.core.groupby.GroupBy.prod
================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.prod